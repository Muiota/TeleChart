Please use DATA_URL in index.html for set base url.

Todo list:
- text changing animations
- calculation performance
- design features
- animatin transitions

Fixes:
 - 15.04.2019 23:00 CET zoom animation fixed

Thanks!
